var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/client-info/route.js")
R.c("server/chunks/[root-of-the-server]__3b20cbef._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_client-info_route_actions_3817ecb3.js")
R.m(42256)
module.exports=R.m(42256).exports
