var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/search/route.js")
R.c("server/chunks/[root-of-the-server]__629fce01._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_search_route_actions_4244da48.js")
R.m(62518)
module.exports=R.m(62518).exports
